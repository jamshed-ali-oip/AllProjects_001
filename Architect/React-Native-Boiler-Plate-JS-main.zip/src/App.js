import Navigation from '@src/@core/Navigation';

const App = () => {
  return <Navigation />;
};

export default App;
