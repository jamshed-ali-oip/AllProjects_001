import React from 'react';
import {View, Text} from 'react-native';

const Home = ({navigation}) => {
  return (
    <View style={{flex: 1, marginTop: 30}}>
      <Text style={{textAlign: 'center'}}>Welcome</Text>
    </View>
  );
};

export default Home;
